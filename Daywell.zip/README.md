﻿# Daywell

A responsive mood journal with a React client and an Express/MongoDB API.

## Features
- Sign up and sign in with bcrypt password hashing and signed JWT sessions
- Private per-user mood entries, one daily check-in with an optional note
- Month calendar, mood legend, and personal check-in count
- Responsive layout, scroll reveal, hover states, and reduced-motion support

## Requirements
- Node.js 18+
- MongoDB Community Server running locally, or a MongoDB Atlas connection string

MongoDB Compass is a visual client for MongoDB; keep the MongoDB server running separately. The default connection is `mongodb://127.0.0.1:27017/daywell`.

## Start the API
```powershell
cd server
Copy-Item .env.example .env
# Edit .env and set JWT_SECRET to a long random value. Set MONGODB_URI if needed.
npm install
npm run dev
```

## Start the web app (second terminal)
```powershell
cd client
npm install
npm run dev
```
Open http://localhost:5173. The Vite development server proxies nothing by default; the client calls `http://localhost:5000/api` (override with `client/.env` and `VITE_API_URL`).

## MongoDB Compass
Connect Compass to `mongodb://127.0.0.1:27017`. The `daywell` database and `users` / `entries` collections are created when the first account and check-in are saved.

## API overview
- `POST /api/auth/signup` `{ name, email, password }`
- `POST /api/auth/signin` `{ email, password }`
- `GET /api/auth/me` (Bearer token)
- `GET /api/entries` (Bearer token)
- `POST /api/entries` `{ mood, note }` (Bearer token)
- `GET /api/health`

User passwords are never stored in plain text. Entries are private to the authenticated account. This starter uses bearer JWTs stored in browser local storage; for a public production deployment, add HTTPS, secure httpOnly cookie sessions, and account recovery flows.
