﻿import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import mongoose from 'mongoose'
import rateLimit from 'express-rate-limit'
import authRoutes from './routes/auth.js'
import entryRoutes from './routes/entries.js'
const app=express()
app.use(helmet())
app.use(cors({origin:process.env.CLIENT_ORIGIN||'http://localhost:5173'}))
app.use(express.json({limit:'10kb'}))
app.use('/api/auth',rateLimit({windowMs:15*60*1000,limit:100,standardHeaders:true,legacyHeaders:false}))
app.get('/api/health',(req,res)=>res.json({status:'ok'}))
app.use('/api/auth',authRoutes)
app.use('/api/entries',entryRoutes)
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({message:'Something went wrong on the server.'})})
const port=process.env.PORT||5000
try{await mongoose.connect(process.env.MONGODB_URI||'mongodb://127.0.0.1:27017/daywell');app.listen(port,()=>console.log(`Daywell API listening on http://localhost:${port}`))}catch(error){console.error('Could not connect to MongoDB:',error.message);process.exit(1)}
